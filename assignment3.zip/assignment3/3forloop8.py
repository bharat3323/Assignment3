#Write a program to print a table of 12 in reverse order
for num in range(121,1,-1):
    if(num%12==0):
        print(num)