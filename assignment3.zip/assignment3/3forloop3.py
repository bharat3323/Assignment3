#Write a program to print the first ten, 3 digit number
for num in range(100,110):
    print(num)