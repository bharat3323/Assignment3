product=1
for num in range(1,11):
    product = product*num
    print(product)