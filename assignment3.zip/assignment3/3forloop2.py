#Write a program to print the first 100 numbers
for i in range(1,101):
    print (i)