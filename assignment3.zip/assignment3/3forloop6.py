#Write a program to print reverse from 100-1
for num in range(100,0,-1):
    print(num)