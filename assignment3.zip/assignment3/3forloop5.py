#Write a program to print odd numbers 1-50
for num in range(1,50+1):
    if(num%2==1):
        print(num)