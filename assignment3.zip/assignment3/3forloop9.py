#Write a program to print the sum of the first 10 numbers
n=10   
sum1=sum(range(1,n+1))
print(sum1)
    