#Write a program to print the first 10 numbers
for i in range(1,11):
    print(i)