#Write a program to print even numbers 1-100
for num in range(1,100+1):
    if num%2==0:
        print(num)