#Write a program to print a table of 12
for num in range(1,121):
    if(num%12==0):
        print(num)